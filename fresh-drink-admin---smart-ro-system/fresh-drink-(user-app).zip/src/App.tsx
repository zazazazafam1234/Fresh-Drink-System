/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { TabType, DispenserOption, WaterLog, NotificationItem } from './types';
import {
  INITIAL_DISPENSERS,
  INITIAL_LOGS,
  INITIAL_NOTIFICATIONS,
} from './data/mockData';
import { StatusBar } from './components/StatusBar';
import { BottomNavBar } from './components/BottomNavBar';
import { HomeScreen } from './components/HomeScreen';
import { DispensingScreen } from './components/DispensingScreen';
import { HistoryScreen } from './components/HistoryScreen';
import { NotificationsScreen } from './components/NotificationsScreen';
import { ProfileScreen } from './components/ProfileScreen';
import { Smartphone, Monitor, CheckCircle } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('home');
  const [isDispensingView, setIsDispensingView] = useState<boolean>(false);
  const [isPhoneFrame, setIsPhoneFrame] = useState<boolean>(true);
  const [currentDispenser, setCurrentDispenser] = useState<DispenserOption>(
    INITIAL_DISPENSERS[0]
  );
  const [logs, setLogs] = useState<WaterLog[]>(INITIAL_LOGS);
  const [notifications, setNotifications] = useState<NotificationItem[]>(
    INITIAL_NOTIFICATIONS
  );
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  // Switch dispenser
  const handleSelectDispenser = (dispenser: DispenserOption) => {
    setCurrentDispenser(dispenser);
    showToast(`สลับใช้งาน: ${dispenser.name}`);
  };

  // Refresh sensor metrics with slight realistic variation
  const handleRefreshMetrics = () => {
    setCurrentDispenser((prev) => ({
      ...prev,
      tds: Math.max(10, Math.min(25, prev.tds + (Math.random() > 0.5 ? 1 : -1))),
      ph: Number((7.0 + Math.random() * 0.4).toFixed(1)),
      turbidity: Number((0.12 + Math.random() * 0.06).toFixed(2)),
      temp: Number((24.8 + Math.random() * 0.6).toFixed(1)),
    }));
    showToast('อัปเดตข้อมูลเซนเซอร์ล่าสุดแล้ว');
  };

  // Complete water dispensing
  const handleCompleteDispense = (newLog: Omit<WaterLog, 'id'>) => {
    const createdLog: WaterLog = {
      ...newLog,
      id: `log-${Date.now()}`,
    };
    setLogs((prev) => [createdLog, ...prev]);
    setIsDispensingView(false);
    showToast(`บันทึกการเติมน้ำสำเร็จ: ${newLog.unitDisplay}`);
  };

  // Trigger manual Auto-Flush simulation
  const handleTriggerAutoFlush = () => {
    const now = new Date();
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(
      now.getMinutes()
    ).padStart(2, '0')}`;

    const newNotif: NotificationItem = {
      id: `notif-${Date.now()}`,
      type: 'success',
      title: 'Auto Flush ทำงานสำเร็จ',
      description:
        'ระบบ Auto Flush ดำเนินการเรียบร้อยแล้ว น้ำสะอาดและพร้อมใช้งาน',
      time: timeStr,
      read: false,
    };

    setNotifications((prev) => [newNotif, ...prev]);
    showToast('ระบบ Auto Flush ดำเนินการเรียบร้อยแล้ว');
  };

  const handleMarkAllNotificationsAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    showToast('ทำเครื่องหมายอ่านทั้งหมดแล้ว');
  };

  // Quick jump helper for user reviewing the 4 photos
  const jumpToScreen = (screenName: 'photo4-home' | 'photo3-dispense' | 'photo1-history' | 'photo2-notif') => {
    if (screenName === 'photo4-home') {
      setIsDispensingView(false);
      setActiveTab('home');
    } else if (screenName === 'photo3-dispense') {
      setIsDispensingView(true);
    } else if (screenName === 'photo1-history') {
      setIsDispensingView(false);
      setActiveTab('history');
    } else if (screenName === 'photo2-notif') {
      setIsDispensingView(false);
      setActiveTab('notifications');
    }
  };

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <div className="min-h-screen bg-slate-900 text-slate-800 flex flex-col items-center justify-start p-2 sm:p-6 font-['Prompt',sans-serif]">
      {/* Top Outer Control Bar (Screen Selector & Device Frame Toggle) */}
      <header className="w-full max-w-2xl mb-4 bg-slate-800/80 backdrop-blur-md rounded-2xl p-3 border border-slate-700/60 shadow-lg text-white">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          {/* Title & info */}
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-sky-400 animate-pulse" />
            <div>
              <h1 className="text-xs font-bold tracking-wide uppercase text-slate-300">
                Fresh Drink Mobile UI
              </h1>
              <p className="text-[11px] text-slate-400">
                จำลองหน้าจอแอปพลิเคชันตามรูปต้นฉบับ 4 รูป
              </p>
            </div>
          </div>

          {/* Device Frame Mode Toggle */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setIsPhoneFrame(true)}
              className={`px-2.5 py-1.5 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-all ${
                isPhoneFrame
                  ? 'bg-sky-500 text-white shadow-xs'
                  : 'text-slate-400 hover:text-white bg-slate-700/50'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>กรอบ iPhone</span>
            </button>
            <button
              type="button"
              onClick={() => setIsPhoneFrame(false)}
              className={`px-2.5 py-1.5 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-all ${
                !isPhoneFrame
                  ? 'bg-sky-500 text-white shadow-xs'
                  : 'text-slate-400 hover:text-white bg-slate-700/50'
              }`}
            >
              <Monitor className="w-3.5 h-3.5" />
              <span>เต็มจอ</span>
            </button>
          </div>
        </div>

        {/* Quick jump tabs matching the 4 user photos */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 mt-3 pt-2.5 border-t border-slate-700/50">
          <button
            type="button"
            onClick={() => jumpToScreen('photo4-home')}
            className={`px-2 py-1.5 rounded-lg text-[11px] font-medium text-center transition-all ${
              !isDispensingView && activeTab === 'home'
                ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40'
                : 'text-slate-400 hover:bg-slate-700/40 hover:text-slate-200'
            }`}
          >
            รูป 4: หน้าแรก
          </button>
          <button
            type="button"
            onClick={() => jumpToScreen('photo3-dispense')}
            className={`px-2 py-1.5 rounded-lg text-[11px] font-medium text-center transition-all ${
              isDispensingView
                ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40'
                : 'text-slate-400 hover:bg-slate-700/40 hover:text-slate-200'
            }`}
          >
            รูป 3: กำลังเติมน้ำ
          </button>
          <button
            type="button"
            onClick={() => jumpToScreen('photo1-history')}
            className={`px-2 py-1.5 rounded-lg text-[11px] font-medium text-center transition-all ${
              !isDispensingView && activeTab === 'history'
                ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40'
                : 'text-slate-400 hover:bg-slate-700/40 hover:text-slate-200'
            }`}
          >
            รูป 1: ประวัติการใช้น้ำ
          </button>
          <button
            type="button"
            onClick={() => jumpToScreen('photo2-notif')}
            className={`px-2 py-1.5 rounded-lg text-[11px] font-medium text-center transition-all ${
              !isDispensingView && activeTab === 'notifications'
                ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40'
                : 'text-slate-400 hover:bg-slate-700/40 hover:text-slate-200'
            }`}
          >
            รูป 2: การแจ้งเตือน
          </button>
        </div>
      </header>

      {/* Main Container (Simulated iPhone 16 Pro or Full Width View) */}
      <main
        className={`w-full transition-all duration-300 ${
          isPhoneFrame
            ? 'max-w-[420px] rounded-[52px] bg-slate-900 p-3 shadow-2xl ring-1 ring-slate-700/80'
            : 'max-w-md rounded-3xl bg-slate-50 shadow-xl overflow-hidden'
        }`}
      >
        {/* Inner Phone Screen Content */}
        <div
          className={`w-full bg-[#f8fafc] flex flex-col relative overflow-hidden ${
            isPhoneFrame
              ? 'rounded-[44px] min-h-[860px] border border-slate-200/60 shadow-inner'
              : 'min-h-[820px]'
          }`}
        >
          {/* iOS Status Bar */}
          <StatusBar />

          {/* Toast Notification Banner */}
          {toastMessage && (
            <div className="absolute top-14 left-4 right-4 z-50 bg-slate-900/90 backdrop-blur-md text-white px-4 py-2.5 rounded-2xl shadow-lg flex items-center gap-2 text-xs animate-in fade-in slide-in-from-top-3 duration-200">
              <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
              <span className="font-medium">{toastMessage}</span>
            </div>
          )}

          {/* Active Screen View */}
          <div className="flex-1 overflow-y-auto">
            {isDispensingView ? (
              /* Screen 2: กำลังเติมน้ำ (Image 3) */
              <DispensingScreen
                onBack={() => setIsDispensingView(false)}
                onCompleteDispense={handleCompleteDispense}
                dispenserName={currentDispenser.name}
              />
            ) : activeTab === 'home' ? (
              /* Screen 1: หน้าแรก (Image 4) */
              <HomeScreen
                currentDispenser={currentDispenser}
                allDispensers={INITIAL_DISPENSERS}
                onSelectDispenser={handleSelectDispenser}
                onNavigateToDispense={() => setIsDispensingView(true)}
                onRefreshMetrics={handleRefreshMetrics}
              />
            ) : activeTab === 'history' ? (
              /* Screen 3: ประวัติการใช้น้ำ (Image 1) */
              <HistoryScreen
                onBack={() => setActiveTab('home')}
                logs={logs}
              />
            ) : activeTab === 'notifications' ? (
              /* Screen 4: การแจ้งเตือน (Image 2) */
              <NotificationsScreen
                onBack={() => setActiveTab('home')}
                notifications={notifications}
                onTriggerAutoFlush={handleTriggerAutoFlush}
                onMarkAllAsRead={handleMarkAllNotificationsAsRead}
              />
            ) : (
              /* Screen 5: โปรไฟล์ & ระบบ */
              <ProfileScreen currentDispenser={currentDispenser} />
            )}
          </div>

          {/* Bottom Navigation Bar (Shown when not in modal dispensing mode) */}
          {!isDispensingView && (
            <BottomNavBar
              activeTab={activeTab}
              onChangeTab={(tab) => {
                setActiveTab(tab);
                setIsDispensingView(false);
              }}
              unreadCount={unreadCount}
            />
          )}
        </div>
      </main>
    </div>
  );
}
